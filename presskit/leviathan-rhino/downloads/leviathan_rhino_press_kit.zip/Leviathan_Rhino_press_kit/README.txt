Leviathan: Rhino press kit
Developer: AmortizGames (Kyrgyzstan). Steam publisher: solarsuit.games.
Steam: https://store.steampowered.com/app/4784510/Leviathan_Rhino/
Press page: https://amortizgames.github.io/presskit/leviathan-rhino/
Contact: amortizgames@gmail.com
Free to use for editorial coverage. All images are captured in-game.
